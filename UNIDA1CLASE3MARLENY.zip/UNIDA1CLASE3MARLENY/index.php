<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <title>Mi proyecto Php</title>
</head>
<body>
<div class="jumbotron text-center">
     <h1>SEMANA 3 Trabajando interfaces con Bootstrap</h1>
    <p> Este sitio incluye bootstrap y es un  ejemplo del diseño responsive.</p>
     </div>

    <br>
    <div class="container">
    <nav class="navbar navbar-expand-sm bg-dark">

    <!--Links-->
    <u1 class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="#"><p style="color:Magenta";>Tablas</p></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="./imagenes.php"><p style="color:GreenYellow";>Imagenes</p></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="./alertas.php"><p style="color:Gold";>Alertas</p></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="./botones.php">Botones</a>
      </li>
     </u1>  

     </nav> 
    </div>
    <br>
    <div class="container">
         <h1>EJEMPLO DE PROYECTO EN REPOSITORIO</h1>
        <h2>HOLA ESTE ES MI EJEMPLO TRABAJANDO CON TABLAS</h2> 
    

    <h3>Ejemplo con th</h3>
    <table class="table">
        <tr class="table-dark">
            <th><p style="color:SkyBlue";>Nombre</p></th>
            <th><p style="color:orange";>Nombre</p></th>
            <th>Edad</th>
        </tr>
         <tr>
            <td>SERGIO</td>
            <td>SANTOS</td>
            <td>19</td>
        </tr>  
        <tr>
            <td>LAIZA</td>
            <td>LEON</td>
            <td>21</td>
        </tr>  
        <tr>
            <td>WENDY</td>
            <td>PEÑA</td>
            <td>20</td>
        </tr>  
    </table>

    <h3>Ejemplo sin th</h3>
    <table  class=" table table-striped">
         <tr>
            <td>SERGIO</td>
            <td>SANTOS</td>
            <td>19</td>
        </tr>  
        <tr>
            <td>LAIZA</td>
            <td>LEON</td>
            <td>21</td>
        </tr>  
        <tr>
        <td>WENDY</td>
            <td>PEÑA</td>
            <td>20</td>
        </tr>  
    </table>

    <h3>Ejemplo con th</h3>
    <table class="table table-bordered ">
    <tr>
            <td>SERGIO</td>
            <td>SANTOS</td>
            <td>19</td>
        </tr>  
        <tr>
            <td>LAIZA</td>
            <td>LEON</td>
            <td>21</td>
        </tr>  
        <tr>
        <td>WENDY</td>
            <td>PEÑA</td>
            <td>20</td>
        </tr>
    </table>

    <h3>Ejemplo con th</h3>
    <table class="table table-bordered table-hover">
    <tr>
            <td>SERGIO</td>
            <td>SANTOS</td>
            <td>19</td>
        </tr>  
        <tr>
            <td>LAIZA</td>
            <td>LEON</td>
            <td>21</td>
        </tr>  
        <tr>
        <td>WENDY</td>
            <td>PEÑA</td>
            <td>20</td>
        </tr>
    </table>

    <h3>Ejemplo con th1</h3>
    <table class="table">
        <thead class="thead-dark">
        <tr>
            <td>SERGIO</td>
            <td>SANTOS</td>
            <td>19</td>
        </tr>  
        <tr>
            <td>LAIZA</td>
            <td>LEON</td>
            <td>21</td>
        </tr>  
        <tr>
        <td>WENDY</td>
            <td>PEÑA</td>
            <td>20</td>
        </tr>
        </tbody>    
    </table>
    </div>
</body>
</html>