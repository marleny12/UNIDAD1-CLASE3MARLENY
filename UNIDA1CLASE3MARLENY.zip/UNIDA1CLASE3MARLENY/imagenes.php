<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <title>Mi proyecto Php</title>
</head>
<body>
<div class="jumbotron text-center">
     <h1>SEMANA 3 Trabajando interfaces con Bootstrap</h1>
    <p> Este sitio incluye bootstrap y es un  ejemplo del diseño responsive.</p>
     </div>

    <br>
    <div class="container">
    <nav class="navbar navbar-expand-sm bg-dark">

    <!--Links-->
    <u1 class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="./index.php">Tablas</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Imagenes</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="./alertas.php">Alertas</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="./botones.php">Botones</a>
      </li>
     </u1>  

     </nav> 
    </div>
    <br>
    <div class="container">
         <h1>EJEMPLO DE PROYECTO EN REPOSITORIO</h1>
        <h2>HOLA ESTE ES MI EJEMPLO TRABAJANDO CON IMAGENES</h2>
        <img src="./imagenes/foto2.JPG" class="rounded" alt="CAPTUS " title="Raptor"/> 
        <img src="./imagenes/foto5.JPG" class="rounded-circle" alt="FLORES" title="FLORES"/>
        <img src="./imagenes/foto7.JPG" class="img-thumbnail" alt="STICH" title=""/> 
        <img src="./imagenes/foto8.PNG" class="img-fluid" alt="" title="a"/>  
        <br/>
        <img src="./imagenes/foto9.JFIF" alt="Dance it our" title="Dance it ou" class="img-fluid"  style="width:270px;heigth:270px"/> 
        <img src="./imagenes/foto10.JFIF" alt="Dance it our" title="Dance it ou" class="img-fluid"  style="width:900px;heigth:270px"/> 
        <br>
        <a href="./index.php">
          <img src="./imagenes/foto1.JPG"  alt="stich"  title="Ir al inicio" />
        </a> 
        <a href="http://www.google.com">
          <img src="./imagenes/foto3.JPG"  alt="you're my person "  title="Ir al Google" />
        </a>     
    </div>
</body>
</html>